export const colors = {
  // Primary Brand Colors
  primary: '#6366F1', // Indigo
  primaryLight: '#818CF8',
  primaryDark: '#4F46E5',
  
  // Secondary Colors
  secondary: '#EC4899', // Pink
  secondaryLight: '#F472B6',
  secondaryDark: '#DB2777',
  
  // Accent Colors
  accent: '#8B5CF6', // Purple
  accentLight: '#A78BFA',
  accentDark: '#7C3AED',
  
  // Status Colors
  success: '#10B981', // Green
  successLight: '#34D399',
  successDark: '#059669',
  
  warning: '#F59E0B', // Amber
  warningLight: '#FBBF24',
  warningDark: '#D97706',
  
  error: '#EF4444', // Red
  errorLight: '#F87171',
  errorDark: '#DC2626',
  
  // Background Colors
  background: '#F9FAFB', // Very light gray
  cardBackground: '#FFFFFF', // White
  modalBackground: '#FFFFFF', // White
  inputBackground: '#F3F4F6', // Light gray
  disabledBackground: '#E5E7EB', // Gray
  
  // Message Colors (for chat)
  messageBackground: '#F3F4F6', // Light gray
  messageText: '#1F2937', // Dark gray
  
  // Text Colors
  textPrimary: '#1F2937', // Dark gray
  textSecondary: '#6B7280', // Medium gray
  white: '#FFFFFF', // White
  
  // Border Colors
  border: '#E5E7EB', // Light gray
  disabledBorder: '#D1D5DB', // Light gray
  
  // Utility Colors
  divider: '#E5E7EB', // Light gray
  gray: '#9CA3AF', // Medium gray
  overlay: 'rgba(0, 0, 0, 0.5)', // Black with opacity
  shadow: 'rgba(0, 0, 0, 0.1)', // Black with opacity
};

// We'll create a separate dark theme implementation in a future update

export const shadows = {
  small: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  medium: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  large: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 8,
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  round: 9999,
};