import React, { useState } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Platform,
  KeyboardAvoidingView,
  Keyboard,
} from 'react-native';
import { Camera, Mic, Plus, SendHorizontal, Smile } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import * as ImagePicker from 'expo-image-picker';

interface ChatInputProps {
  onSendMessage: (text: string, type: 'text' | 'image') => void;
  onStartRecording?: () => void;
  onStopRecording?: () => void;
  disabled?: boolean;
}

export function ChatInput({
  onSendMessage,
  onStartRecording,
  onStopRecording,
  disabled = false,
}: ChatInputProps) {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showAttachments, setShowAttachments] = useState(false);
  
  const handleSend = () => {
    if (message.trim()) {
      onSendMessage(message.trim(), 'text');
      setMessage('');
      Keyboard.dismiss();
    }
  };
  
  const handleAttachmentPress = () => {
    setShowAttachments(!showAttachments);
  };
  
  const handleCameraPress = async () => {
    try {
      const permissionResult = await ImagePicker.requestCameraPermissionsAsync();
      
      if (permissionResult.granted === false) {
        alert('Camera permission is required to take photos!');
        return;
      }
      
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });
      
      if (!result.canceled) {
        onSendMessage(result.assets[0].uri, 'image');
        setShowAttachments(false);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
    }
  };
  
  const handleGalleryPress = async () => {
    try {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      
      if (permissionResult.granted === false) {
        alert('Gallery permission is required to select photos!');
        return;
      }
      
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });
      
      if (!result.canceled) {
        onSendMessage(result.assets[0].uri, 'image');
        setShowAttachments(false);
      }
    } catch (error) {
      console.error('Error picking photo:', error);
    }
  };
  
  const handleVoicePress = () => {
    setIsRecording(!isRecording);
    
    if (isRecording) {
      onStopRecording?.();
    } else {
      onStartRecording?.();
    }
  };
  
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <View style={styles.container}>
        {showAttachments && (
          <View style={styles.attachmentsContainer}>
            <TouchableOpacity style={styles.attachmentButton} onPress={handleCameraPress}>
              <Camera size={24} color={colors.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.attachmentButton} onPress={handleGalleryPress}>
              <Plus size={24} color={colors.textPrimary} />
            </TouchableOpacity>
          </View>
        )}
        
        <View style={styles.inputContainer}>
          <TouchableOpacity style={styles.iconButton} onPress={handleAttachmentPress}>
            <Plus size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          
          <TextInput
            style={styles.input}
            placeholder="Message..."
            placeholderTextColor={colors.textSecondary}
            value={message}
            onChangeText={setMessage}
            multiline
            editable={!disabled}
          />
          
          <TouchableOpacity style={styles.iconButton}>
            <Smile size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          
          {message.trim() ? (
            <TouchableOpacity style={styles.sendButton} onPress={handleSend} disabled={disabled}>
              <SendHorizontal size={24} color={colors.white} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.iconButton, isRecording && styles.recordingButton]}
              onPress={handleVoicePress}
              disabled={disabled}
            >
              <Mic size={24} color={isRecording ? colors.white : colors.textPrimary} />
            </TouchableOpacity>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  attachmentsContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: colors.inputBackground,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  attachmentButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 4,
  },
  recordingButton: {
    backgroundColor: colors.error,
  },
  input: {
    flex: 1,
    backgroundColor: colors.inputBackground,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    maxHeight: 100,
    fontSize: 16,
    color: colors.textPrimary,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 4,
  },
});