import React from 'react';
import { View, Text, StyleSheet, Image, Dimensions } from 'react-native';
import { format } from 'date-fns';
import { colors } from '@/constants/theme';

export type MessageType = 'text' | 'image' | 'emoji';

interface ChatBubbleProps {
  message: string;
  timestamp: Date;
  isCurrentUser: boolean;
  type?: MessageType;
  status?: 'sent' | 'delivered' | 'read';
}

export function ChatBubble({
  message,
  timestamp,
  isCurrentUser,
  type = 'text',
  status = 'sent',
}: ChatBubbleProps) {
  const formattedTime = format(timestamp, 'h:mm a');
  
  const renderContent = () => {
    switch (type) {
      case 'image':
        return (
          <Image
            source={{ uri: message }}
            style={styles.image}
            resizeMode="cover"
          />
        );
      case 'emoji':
        return <Text style={styles.emoji}>{message}</Text>;
      case 'text':
      default:
        return <Text style={[styles.messageText, isCurrentUser && styles.currentUserMessageText]}>{message}</Text>;
    }
  };
  
  const renderStatus = () => {
    if (!isCurrentUser) return null;
    
    let statusText = '';
    switch (status) {
      case 'sent':
        statusText = 'Sent';
        break;
      case 'delivered':
        statusText = 'Delivered';
        break;
      case 'read':
        statusText = 'Read';
        break;
    }
    
    return <Text style={styles.status}>{statusText}</Text>;
  };
  
  return (
    <View style={[styles.container, isCurrentUser && styles.currentUserContainer]}>
      <View
        style={[
          styles.bubble,
          isCurrentUser ? styles.currentUserBubble : styles.otherUserBubble,
          type === 'emoji' && styles.emojiBubble,
        ]}
      >
        {renderContent()}
        <View style={styles.metaContainer}>
          <Text style={styles.time}>{formattedTime}</Text>
          {renderStatus()}
        </View>
      </View>
    </View>
  );
}

const { width } = Dimensions.get('window');
const MAX_BUBBLE_WIDTH = width * 0.75;

const styles = StyleSheet.create({
  container: {
    marginVertical: 2,
    paddingHorizontal: 16,
    flexDirection: 'row',
  },
  currentUserContainer: {
    justifyContent: 'flex-end',
  },
  bubble: {
    borderRadius: 16,
    padding: 12,
    maxWidth: MAX_BUBBLE_WIDTH,
  },
  currentUserBubble: {
    backgroundColor: colors.primary,
    borderBottomRightRadius: 4,
  },
  otherUserBubble: {
    backgroundColor: colors.messageBackground,
    borderBottomLeftRadius: 4,
  },
  emojiBubble: {
    backgroundColor: 'transparent',
    padding: 0,
  },
  messageText: {
    fontSize: 16,
    color: colors.messageText,
  },
  currentUserMessageText: {
    color: colors.white,
  },
  emoji: {
    fontSize: 40,
  },
  image: {
    width: MAX_BUBBLE_WIDTH - 24,
    height: (MAX_BUBBLE_WIDTH - 24) * 0.75,
    borderRadius: 12,
  },
  metaContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 4,
    gap: 4,
  },
  time: {
    fontSize: 10,
    color: colors.white,
    opacity: 0.7,
  },
  status: {
    fontSize: 10,
    color: colors.white,
    opacity: 0.7,
  },
});