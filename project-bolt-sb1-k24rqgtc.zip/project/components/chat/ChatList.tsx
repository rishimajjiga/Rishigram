import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Avatar } from '@/components/ui/Avatar';
import { colors } from '@/constants/theme';
import { formatDistanceToNow } from 'date-fns';
import { router } from 'expo-router';

export interface ChatItemProps {
  id: string;
  user: {
    id: string;
    username: string;
    avatarUrl: string | null;
    isOnline: boolean;
  };
  lastMessage: {
    text: string;
    timestamp: Date;
    isRead: boolean;
    senderId: string;
  };
  unreadCount: number;
}

interface ChatListProps {
  chats: ChatItemProps[];
  currentUserId: string;
  onRefresh?: () => void;
  refreshing?: boolean;
}

export function ChatItem({
  id,
  user,
  lastMessage,
  unreadCount,
  currentUserId,
}: ChatItemProps & { currentUserId: string }) {
  const isLastMessageFromCurrentUser = lastMessage.senderId === currentUserId;
  const formattedTime = formatDistanceToNow(lastMessage.timestamp, { addSuffix: true });
  
  const navigateToChat = () => {
    router.push(`/chat/${id}`);
  };
  
  return (
    <TouchableOpacity style={styles.chatItem} onPress={navigateToChat}>
      <Avatar
        uri={user.avatarUrl}
        initials={user.username.substring(0, 2)}
        size="lg"
        showOnlineIndicator
        isOnline={user.isOnline}
      />
      
      <View style={styles.chatInfo}>
        <View style={styles.chatHeader}>
          <Text style={styles.username}>{user.username}</Text>
          <Text style={styles.timestamp}>{formattedTime}</Text>
        </View>
        
        <View style={styles.messagePreview}>
          <Text
            style={[
              styles.lastMessage,
              !lastMessage.isRead && !isLastMessageFromCurrentUser && styles.unreadMessage,
            ]}
            numberOfLines={1}
          >
            {isLastMessageFromCurrentUser ? 'You: ' : ''}
            {lastMessage.text}
          </Text>
          
          {unreadCount > 0 && !isLastMessageFromCurrentUser && (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadCount}>{unreadCount}</Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

export function ChatList({
  chats,
  currentUserId,
  onRefresh,
  refreshing = false
}: ChatListProps) {
  return (
    <FlatList
      data={chats}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <ChatItem {...item} currentUserId={currentUserId} />
      )}
      contentContainerStyle={styles.list}
      onRefresh={onRefresh}
      refreshing={refreshing}
    />
  );
}

const styles = StyleSheet.create({
  list: {
    paddingVertical: 8,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  chatInfo: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  username: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  timestamp: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  messagePreview: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  lastMessage: {
    fontSize: 14,
    color: colors.textSecondary,
    flex: 1,
  },
  unreadMessage: {
    fontWeight: '600',
    color: colors.textPrimary,
  },
  unreadBadge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
    marginLeft: 8,
  },
  unreadCount: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
});