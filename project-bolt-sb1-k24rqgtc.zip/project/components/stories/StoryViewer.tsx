import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Dimensions,
  Animated,
  Platform,
} from 'react-native';
import { Avatar } from '@/components/ui/Avatar';
import { X, MessageSquare } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import { formatDistanceToNow } from 'date-fns';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface StoryItem {
  id: string;
  imageUrl: string;
  timestamp: Date;
}

interface StoryUser {
  id: string;
  username: string;
  avatarUrl: string | null;
}

interface StoryViewerProps {
  stories: StoryItem[];
  user: StoryUser;
  onClose: () => void;
  onReply: (storyId: string) => void;
  initialStoryIndex?: number;
}

export function StoryViewer({
  stories,
  user,
  onClose,
  onReply,
  initialStoryIndex = 0,
}: StoryViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialStoryIndex);
  const [isPaused, setIsPaused] = useState(false);
  const progressAnim = useRef(stories.map(() => new Animated.Value(0))).current;
  const storyTimeout = useRef<NodeJS.Timeout | null>(null);
  
  const STORY_DURATION = 5000; // 5 seconds per story
  
  useEffect(() => {
    // Start the animation for the current story
    startProgressAnimation();
    
    return () => {
      // Clean up the timeout when component unmounts or story changes
      if (storyTimeout.current) {
        clearTimeout(storyTimeout.current);
      }
    };
  }, [currentIndex, isPaused]);
  
  const startProgressAnimation = () => {
    if (isPaused) return;
    
    // Reset the current animation
    progressAnim[currentIndex].setValue(0);
    
    // Animate the progress
    Animated.timing(progressAnim[currentIndex], {
      toValue: 1,
      duration: STORY_DURATION,
      useNativeDriver: false,
    }).start(({ finished }) => {
      if (finished) {
        // Go to next story when animation completes
        goToNextStory();
      }
    });
    
    // Backup timeout in case animation fails
    storyTimeout.current = setTimeout(goToNextStory, STORY_DURATION);
  };
  
  const goToNextStory = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // No more stories, close the viewer
      onClose();
    }
    
    if (storyTimeout.current) {
      clearTimeout(storyTimeout.current);
    }
  };
  
  const goToPrevStory = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
    
    if (storyTimeout.current) {
      clearTimeout(storyTimeout.current);
    }
  };
  
  const pauseStory = () => {
    setIsPaused(true);
    progressAnim[currentIndex].stopAnimation();
    if (storyTimeout.current) {
      clearTimeout(storyTimeout.current);
    }
  };
  
  const resumeStory = () => {
    setIsPaused(false);
    // Get the current progress value and resume from there
    progressAnim[currentIndex].stopAnimation((value) => {
      const remainingTime = STORY_DURATION * (1 - value);
      
      Animated.timing(progressAnim[currentIndex], {
        toValue: 1,
        duration: remainingTime,
        useNativeDriver: false,
      }).start(({ finished }) => {
        if (finished) {
          goToNextStory();
        }
      });
      
      storyTimeout.current = setTimeout(goToNextStory, remainingTime);
    });
  };
  
  const handleTapLeft = () => {
    goToPrevStory();
  };
  
  const handleTapRight = () => {
    goToNextStory();
  };
  
  const handlePressIn = () => {
    pauseStory();
  };
  
  const handlePressOut = () => {
    resumeStory();
  };
  
  const handleReply = () => {
    pauseStory();
    onReply(stories[currentIndex].id);
  };
  
  const currentStory = stories[currentIndex];
  const formattedTime = formatDistanceToNow(currentStory.timestamp, { addSuffix: true });
  
  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['rgba(0,0,0,0.5)', 'transparent', 'transparent', 'rgba(0,0,0,0.2)']}
        style={styles.gradient}
      >
        {/* Progress bars */}
        <View style={styles.progressContainer}>
          {stories.map((_, index) => (
            <View key={index} style={styles.progressBarBackground}>
              <Animated.View
                style={[
                  styles.progressBar,
                  {
                    width: progressAnim[index].interpolate({
                      inputRange: [0, 1],
                      outputRange: ['0%', '100%'],
                    }),
                    backgroundColor:
                      index < currentIndex
                        ? colors.white
                        : index === currentIndex
                        ? colors.white
                        : 'rgba(255, 255, 255, 0.5)',
                  },
                ]}
              />
            </View>
          ))}
        </View>
        
        {/* User info */}
        <View style={styles.header}>
          <View style={styles.userInfo}>
            <Avatar
              uri={user.avatarUrl}
              initials={user.username.substring(0, 2)}
              size="sm"
              showBorder
            />
            <View>
              <Text style={styles.username}>{user.username}</Text>
              <Text style={styles.timestamp}>{formattedTime}</Text>
            </View>
          </View>
          
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <X size={24} color={colors.white} />
          </TouchableOpacity>
        </View>
      </LinearGradient>
      
      {/* Story image */}
      <Image
        source={{ uri: currentStory.imageUrl }}
        style={styles.storyImage}
        resizeMode="cover"
      />
      
      {/* Touch areas */}
      <View style={styles.touchContainer}>
        <TouchableOpacity
          style={styles.touchLeft}
          onPress={handleTapLeft}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          activeOpacity={1}
        />
        <TouchableOpacity
          style={styles.touchRight}
          onPress={handleTapRight}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          activeOpacity={1}
        />
      </View>
      
      {/* Footer with reply */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.replyButton} onPress={handleReply}>
          <MessageSquare size={24} color={colors.white} />
          <Text style={styles.replyText}>Reply</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  gradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 150,
    zIndex: 2,
    paddingTop: Platform.OS === 'ios' ? 48 : 24,
  },
  progressContainer: {
    flexDirection: 'row',
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  progressBarBackground: {
    flex: 1,
    height: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginHorizontal: 2,
    borderRadius: 1,
  },
  progressBar: {
    height: '100%',
    borderRadius: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  username: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
  timestamp: {
    color: colors.white,
    opacity: 0.8,
    fontSize: 12,
  },
  closeButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  storyImage: {
    ...StyleSheet.absoluteFillObject,
  },
  touchContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  touchLeft: {
    flex: 1,
  },
  touchRight: {
    flex: 1,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    zIndex: 2,
  },
  replyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 8,
    paddingHorizontal: 16,
    borderRadius: 24,
    alignSelf: 'center',
  },
  replyText: {
    color: colors.white,
    marginLeft: 8,
    fontWeight: '500',
  },
});