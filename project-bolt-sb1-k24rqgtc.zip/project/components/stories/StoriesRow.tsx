import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { Avatar } from '@/components/ui/Avatar';
import LinearGradient from 'expo-linear-gradient';
import { colors } from '@/constants/theme';
import { Plus } from 'lucide-react-native';

export interface StoryProps {
  id: string;
  username: string;
  avatarUrl: string | null;
  hasUnseenStory: boolean;
  seen?: boolean;
}

interface StoriesRowProps {
  stories: StoryProps[];
  onStoryPress: (id: string) => void;
  onAddStoryPress: () => void;
}

export function StoriesRow({ stories, onStoryPress, onAddStoryPress }: StoriesRowProps) {
  const renderStoryItem = (story: StoryProps, index: number) => {
    const { id, username, avatarUrl, hasUnseenStory, seen } = story;
    
    return (
      <TouchableOpacity
        key={id}
        style={styles.storyContainer}
        onPress={() => onStoryPress(id)}
      >
        <View style={styles.avatarContainer}>
          {hasUnseenStory && !seen ? (
            <LinearGradient
              colors={['#FF5F6D', '#FFC371']}
              style={styles.storyRing}
              start={[0, 0]}
              end={[1, 1]}
            >
              <View style={styles.avatarWrapper}>
                <Avatar
                  uri={avatarUrl}
                  initials={username.substring(0, 2)}
                  size="lg"
                />
              </View>
            </LinearGradient>
          ) : (
            <View style={[styles.storyRing, seen && styles.seenStoryRing]}>
              <View style={styles.avatarWrapper}>
                <Avatar
                  uri={avatarUrl}
                  initials={username.substring(0, 2)}
                  size="lg"
                />
              </View>
            </View>
          )}
        </View>
        <Text style={styles.username} numberOfLines={1}>
          {index === 0 ? 'Your Story' : username}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Add Story Button */}
        <TouchableOpacity style={styles.storyContainer} onPress={onAddStoryPress}>
          <View style={styles.addStoryContainer}>
            <View style={styles.addButton}>
              <Plus size={18} color={colors.white} />
            </View>
            <Avatar
              uri={stories[0]?.avatarUrl}
              initials={stories[0]?.username.substring(0, 2)}
              size="lg"
            />
          </View>
          <Text style={styles.username}>Add Story</Text>
        </TouchableOpacity>

        {/* Stories */}
        {stories.map(renderStoryItem)}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 8,
    backgroundColor: colors.cardBackground,
  },
  scrollContent: {
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  storyContainer: {
    alignItems: 'center',
    marginHorizontal: 8,
    width: 72,
  },
  avatarContainer: {
    marginBottom: 4,
  },
  storyRing: {
    width: 68,
    height: 68,
    borderRadius: 34,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.border,
  },
  seenStoryRing: {
    borderColor: colors.disabledBorder,
  },
  avatarWrapper: {
    borderWidth: 2,
    borderRadius: 30,
    borderColor: colors.cardBackground,
  },
  username: {
    fontSize: 12,
    textAlign: 'center',
    marginTop: 4,
    color: colors.textPrimary,
  },
  addStoryContainer: {
    position: 'relative',
  },
  addButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: colors.primary,
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
    borderWidth: 2,
    borderColor: colors.cardBackground,
  },
});