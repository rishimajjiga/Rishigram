import React from 'react';
import { FlatList, StyleSheet, RefreshControl } from 'react-native';
import { PostCard, PostProps } from './PostCard';
import { colors } from '@/constants/theme';

interface PostsListProps {
  posts: PostProps[];
  refreshing?: boolean;
  onRefresh?: () => void;
  ListHeaderComponent?: React.ReactElement;
}

export function PostsList({
  posts,
  refreshing = false,
  onRefresh,
  ListHeaderComponent
}: PostsListProps) {
  return (
    <FlatList
      data={posts}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => <PostCard {...item} />}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.content}
      refreshControl={
        onRefresh ? (
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        ) : undefined
      }
      ListHeaderComponent={ListHeaderComponent}
    />
  );
}

const styles = StyleSheet.create({
  content: {
    paddingBottom: 20,
  },
});