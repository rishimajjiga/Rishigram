import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { Avatar } from '@/components/ui/Avatar';
import { Heart, MessageCircle, Send, Bookmark as BookmarkSimple, MoveHorizontal as MoreHorizontal } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import { formatDistanceToNow } from 'date-fns';
import { router } from 'expo-router';

export interface PostProps {
  id: string;
  user: {
    id: string;
    username: string;
    avatarUrl: string | null;
  };
  imageUrl: string;
  caption: string;
  likesCount: number;
  commentsCount: number;
  timestamp: Date;
  liked?: boolean;
  saved?: boolean;
  location?: string;
}

export function PostCard({
  id,
  user,
  imageUrl,
  caption,
  likesCount,
  commentsCount,
  timestamp,
  liked = false,
  saved = false,
  location
}: PostProps) {
  const [isLiked, setIsLiked] = React.useState(liked);
  const [isSaved, setIsSaved] = React.useState(saved);
  const [localLikesCount, setLocalLikesCount] = React.useState(likesCount);
  
  const handleLike = () => {
    setIsLiked(!isLiked);
    setLocalLikesCount(prev => isLiked ? prev - 1 : prev + 1);
    // In a real app, you would make an API call here
  };
  
  const handleSave = () => {
    setIsSaved(!isSaved);
    // In a real app, you would make an API call here
  };
  
  const navigateToProfile = () => {
    router.push(`/profile/${user.id}`);
  };
  
  const navigateToComments = () => {
    router.push(`/comments/${id}`);
  };
  
  const formattedTime = formatDistanceToNow(timestamp, { addSuffix: true });
  
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.userInfo} onPress={navigateToProfile}>
          <Avatar 
            uri={user.avatarUrl} 
            initials={user.username.substring(0, 2)}
            size="sm"
          />
          <View>
            <Text style={styles.username}>{user.username}</Text>
            {location && <Text style={styles.location}>{location}</Text>}
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity>
          <MoreHorizontal size={20} color={colors.textPrimary} />
        </TouchableOpacity>
      </View>
      
      {/* Image */}
      <Image
        source={{ uri: imageUrl }}
        style={styles.postImage}
        resizeMode="cover"
      />
      
      {/* Actions */}
      <View style={styles.actions}>
        <View style={styles.leftActions}>
          <TouchableOpacity onPress={handleLike} style={styles.actionButton}>
            <Heart 
              size={24} 
              color={isLiked ? colors.error : colors.textPrimary}
              fill={isLiked ? colors.error : 'transparent'} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity onPress={navigateToComments} style={styles.actionButton}>
            <MessageCircle size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Send size={24} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity onPress={handleSave}>
          <BookmarkSimple
            size={24}
            color={isSaved ? colors.primary : colors.textPrimary}
            fill={isSaved ? colors.primary : 'transparent'} 
          />
        </TouchableOpacity>
      </View>
      
      {/* Likes */}
      <Text style={styles.likes}>{localLikesCount} likes</Text>
      
      {/* Caption */}
      <View style={styles.captionContainer}>
        <Text style={styles.captionUsername}>{user.username}</Text>
        <Text style={styles.caption}>{caption}</Text>
      </View>
      
      {/* Comments Count */}
      {commentsCount > 0 && (
        <TouchableOpacity onPress={navigateToComments}>
          <Text style={styles.commentsCount}>
            View all {commentsCount} comments
          </Text>
        </TouchableOpacity>
      )}
      
      {/* Timestamp */}
      <Text style={styles.timestamp}>{formattedTime}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.cardBackground,
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  username: {
    fontWeight: '600',
    fontSize: 14,
    color: colors.textPrimary,
  },
  location: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  postImage: {
    width: '100%',
    height: Dimensions.get('window').width,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
  },
  leftActions: {
    flexDirection: 'row',
    gap: 16,
  },
  actionButton: {
    marginRight: 16,
  },
  likes: {
    fontWeight: '600',
    paddingHorizontal: 12,
    marginBottom: 4,
    color: colors.textPrimary,
  },
  captionContainer: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    marginBottom: 4,
  },
  captionUsername: {
    fontWeight: '600',
    marginRight: 4,
    color: colors.textPrimary,
  },
  caption: {
    flex: 1,
    color: colors.textPrimary,
  },
  commentsCount: {
    color: colors.textSecondary,
    paddingHorizontal: 12,
    marginVertical: 4,
  },
  timestamp: {
    fontSize: 12,
    color: colors.textSecondary,
    paddingHorizontal: 12,
    marginTop: 4,
    marginBottom: 12,
  },
});