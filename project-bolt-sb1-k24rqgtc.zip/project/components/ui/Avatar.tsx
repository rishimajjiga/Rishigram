import React from 'react';
import { View, Image, StyleSheet, ViewStyle, Text } from 'react-native';
import { colors } from '@/constants/theme';

export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface AvatarProps {
  uri?: string | null;
  initials?: string;
  size?: AvatarSize;
  showBorder?: boolean;
  showOnlineIndicator?: boolean;
  isOnline?: boolean;
  style?: ViewStyle;
}

export function Avatar({
  uri,
  initials,
  size = 'md',
  showBorder = false,
  showOnlineIndicator = false,
  isOnline = false,
  style
}: AvatarProps) {
  const getSize = (): number => {
    const sizes: Record<AvatarSize, number> = {
      xs: 24,
      sm: 32,
      md: 40,
      lg: 56,
      xl: 80
    };
    return sizes[size];
  };

  const avatarSize = getSize();
  const initialsSize = avatarSize * 0.4;
  const onlineIndicatorSize = avatarSize * 0.3;
  
  return (
    <View style={[styles.container, style]}>
      <View
        style={[
          styles.avatar,
          {
            width: avatarSize,
            height: avatarSize,
            borderRadius: avatarSize / 2,
            borderWidth: showBorder ? 2 : 0,
          },
        ]}
      >
        {uri ? (
          <Image
            source={{ uri }}
            style={[
              styles.image,
              { width: avatarSize, height: avatarSize, borderRadius: avatarSize / 2 }
            ]}
          />
        ) : (
          <View style={[styles.initials, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.initialsText, { fontSize: initialsSize }]}>
              {initials || '?'}
            </Text>
          </View>
        )}
      </View>
      
      {showOnlineIndicator && (
        <View
          style={[
            styles.onlineIndicator,
            {
              width: onlineIndicatorSize,
              height: onlineIndicatorSize,
              borderRadius: onlineIndicatorSize / 2,
              backgroundColor: isOnline ? colors.success : colors.gray,
              right: 0,
              bottom: 0,
            },
          ]}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  avatar: {
    overflow: 'hidden',
    borderColor: colors.white,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  initials: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  initialsText: {
    color: colors.white,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  onlineIndicator: {
    position: 'absolute',
    borderWidth: 2,
    borderColor: colors.white,
  },
});