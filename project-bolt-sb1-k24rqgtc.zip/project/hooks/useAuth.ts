import { useState, useEffect } from 'react';
import { router } from 'expo-router';
import { createStore } from 'zustand/vanilla';
import { useStore } from 'zustand';

// This is a simplified mock auth implementation
// In a real app, you'd use Firebase Auth, Supabase, or another auth provider

interface User {
  id: string;
  username: string;
  email: string;
  fullName: string;
  avatarUrl: string | null;
  bio: string | null;
  followers: number;
  following: number;
  postsCount: number;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<void>;
}

// Mock user data
const MOCK_USER: User = {
  id: '1',
  username: 'rishi',
  email: 'rishi@example.com',
  fullName: 'Rishi Kumar',
  avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  bio: 'Photography enthusiast | Travel lover | Tech geek',
  followers: 1256,
  following: 426,
  postsCount: 42,
};

const authStore = createStore<AuthState>((set) => ({
  user: null,
  isLoading: true,
  error: null,
  isAuthenticated: false,
  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, validate credentials with backend
      if (email.trim() && password.length >= 6) {
        set({ user: MOCK_USER, isAuthenticated: true, isLoading: false });
        router.replace('/');
      } else {
        set({ error: 'Invalid credentials', isLoading: false });
      }
    } catch (error) {
      set({ error: 'Login failed', isLoading: false });
    }
  },
  register: async (username, email, password) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (username.trim() && email.trim() && password.length >= 6) {
        const newUser = {
          ...MOCK_USER,
          username,
          email,
        };
        set({ user: newUser, isAuthenticated: true, isLoading: false });
        router.replace('/');
      } else {
        set({ error: 'Please fill all fields correctly', isLoading: false });
      }
    } catch (error) {
      set({ error: 'Registration failed', isLoading: false });
    }
  },
  logout: () => {
    set({ user: null, isAuthenticated: false });
    router.replace('/login');
  },
  updateProfile: async (data) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      set(state => ({
        user: state.user ? { ...state.user, ...data } : null,
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Profile update failed', isLoading: false });
    }
  },
}));

export function useAuth() {
  // Connect to the store
  const state = useStore(authStore);
  
  // Initialize auth state
  useEffect(() => {
    const checkAuth = async () => {
      // Simulate checking for saved credentials
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        // For demo, we'll start unauthenticated
        authStore.setState({ isLoading: false, isAuthenticated: false });
      } catch (error) {
        authStore.setState({ isLoading: false, error: 'Auth check failed' });
      }
    };
    
    checkAuth();
  }, []);
  
  return state;
}