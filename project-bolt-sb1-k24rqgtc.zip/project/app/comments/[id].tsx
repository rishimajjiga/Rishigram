import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  TextInput,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ArrowLeft, Send } from 'lucide-react-native';
import { Avatar } from '@/components/ui/Avatar';
import { formatDistanceToNow } from 'date-fns';
import { colors } from '@/constants/theme';

// Comment type
interface Comment {
  id: string;
  text: string;
  user: {
    id: string;
    username: string;
    avatarUrl: string | null;
  };
  timestamp: Date;
  likes: number;
  liked: boolean;
  replies?: Comment[];
}

// Mock comments data
const MOCK_COMMENTS: Record<string, Comment[]> = {
  '1': [
    {
      id: '1',
      text: 'Awesome photo! Where was this taken?',
      user: {
        id: '3',
        username: 'alex_m',
        avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      likes: 5,
      liked: false,
    },
    {
      id: '2',
      text: 'This is beautiful! 😍',
      user: {
        id: '5',
        username: 'emma_d',
        avatarUrl: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      timestamp: new Date(Date.now() - 1.5 * 60 * 60 * 1000), // 1.5 hours ago
      likes: 3,
      liked: true,
    },
    {
      id: '3',
      text: 'Love the composition!',
      user: {
        id: '4',
        username: 'jason23',
        avatarUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      likes: 2,
      liked: false,
    },
    {
      id: '4',
      text: 'What camera did you use for this shot?',
      user: {
        id: '6',
        username: 'michael',
        avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
      likes: 0,
      liked: false,
    },
  ],
};

export default function CommentsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const listRef = useRef<FlatList>(null);
  const [newComment, setNewComment] = useState('');
  
  const postId = id || '1'; // Default to first post if none specified
  const [comments, setComments] = useState<Comment[]>(MOCK_COMMENTS[postId] || []);
  
  const handleAddComment = () => {
    if (!newComment.trim()) return;
    
    const newCommentObj: Comment = {
      id: Date.now().toString(),
      text: newComment.trim(),
      user: {
        id: '1',
        username: 'rishi',
        avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      timestamp: new Date(),
      likes: 0,
      liked: false,
    };
    
    setComments([...comments, newCommentObj]);
    setNewComment('');
    
    // Scroll to bottom
    setTimeout(() => {
      listRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };
  
  const toggleLike = (commentId: string) => {
    setComments(prev =>
      prev.map(comment => {
        if (comment.id === commentId) {
          const newLiked = !comment.liked;
          return {
            ...comment,
            liked: newLiked,
            likes: newLiked ? comment.likes + 1 : comment.likes - 1,
          };
        }
        return comment;
      })
    );
  };
  
  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ArrowLeft size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Comments</Text>
        <View style={{ width: 24 }} />
      </View>
      
      {/* Comments List */}
      <FlatList
        ref={listRef}
        data={comments}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.commentContainer}>
            <Avatar
              uri={item.user.avatarUrl}
              initials={item.user.username.substring(0, 2)}
              size="sm"
            />
            <View style={styles.commentContent}>
              <View style={styles.commentHeader}>
                <Text style={styles.username}>{item.user.username}</Text>
                <Text style={styles.commentText}>{item.text}</Text>
              </View>
              <View style={styles.commentFooter}>
                <Text style={styles.timestamp}>
                  {formatDistanceToNow(item.timestamp, { addSuffix: true })}
                </Text>
                {item.likes > 0 && (
                  <Text style={styles.likes}>{item.likes} likes</Text>
                )}
                <TouchableOpacity onPress={() => toggleLike(item.id)}>
                  <Text style={[styles.actionText, item.liked && styles.likedText]}>
                    {item.liked ? 'Liked' : 'Like'}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity>
                  <Text style={styles.actionText}>Reply</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
        contentContainerStyle={styles.commentsContainer}
      />
      
      {/* Add Comment */}
      <View style={styles.addCommentContainer}>
        <Avatar
          uri="https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          initials="ri"
          size="sm"
        />
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Add a comment..."
            placeholderTextColor={colors.textSecondary}
            value={newComment}
            onChangeText={setNewComment}
            multiline
          />
          {newComment.trim() !== '' && (
            <TouchableOpacity style={styles.sendButton} onPress={handleAddComment}>
              <Send size={20} color={colors.primary} />
            </TouchableOpacity>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  commentsContainer: {
    paddingVertical: 8,
  },
  commentContainer: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  commentContent: {
    flex: 1,
    marginLeft: 12,
  },
  commentHeader: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  username: {
    fontWeight: '600',
    color: colors.textPrimary,
    marginRight: 4,
  },
  commentText: {
    flex: 1,
    color: colors.textPrimary,
  },
  commentFooter: {
    flexDirection: 'row',
    marginTop: 8,
    alignItems: 'center',
  },
  timestamp: {
    fontSize: 12,
    color: colors.textSecondary,
    marginRight: 12,
  },
  likes: {
    fontSize: 12,
    color: colors.textSecondary,
    marginRight: 12,
  },
  actionText: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.textSecondary,
    marginRight: 12,
  },
  likedText: {
    color: colors.primary,
  },
  addCommentContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.cardBackground,
    alignItems: 'center',
  },
  inputContainer: {
    flex: 1,
    marginLeft: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.inputBackground,
    borderRadius: 20,
    paddingHorizontal: 12,
  },
  input: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 16,
    color: colors.textPrimary,
    maxHeight: 100,
  },
  sendButton: {
    padding: 8,
  },
});