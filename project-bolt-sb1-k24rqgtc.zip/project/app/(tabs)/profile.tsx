import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  FlatList,
  Dimensions,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/hooks/useAuth';
import { StatusBar } from 'expo-status-bar';
import { Settings, Grid2x2 as Grid, Bookmark, List, LogOut } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import { Button } from '@/components/ui/Button';
import { PostProps } from '@/components/post/PostCard';
import { router } from 'expo-router';

// Mock posts for profile
const MOCK_POSTS: Omit<PostProps, 'user'>[] = Array.from({ length: 12 }, (_, i) => {
  const id = (i + 1).toString();
  return {
    id,
    imageUrl: `https://images.pexels.com/photos/${900000 + i * 12345}/pexels-photo-${900000 + i * 12345}.jpeg?auto=compress&cs=tinysrgb&w=400`,
    caption: `Post ${id} caption. #rishigram #awesome`,
    likesCount: Math.floor(Math.random() * 1000),
    commentsCount: Math.floor(Math.random() * 100),
    timestamp: new Date(Date.now() - i * 24 * 60 * 60 * 1000), // i days ago
  };
});

// Tab type for profile tabs
type ProfileTab = 'posts' | 'saved';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const dimensions = useWindowDimensions();
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<ProfileTab>('posts');
  
  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }
  
  const handleLogout = () => {
    logout();
  };
  
  const handleEditProfile = () => {
    // In a real app, navigate to edit profile screen
    alert('Edit profile functionality would open here');
  };
  
  const NUM_COLUMNS = 3;
  const ITEM_WIDTH = dimensions.width / NUM_COLUMNS;
  
  const renderGridItem = ({ item }: { item: Omit<PostProps, 'user'> }) => (
    <TouchableOpacity
      style={[styles.gridItem, { width: ITEM_WIDTH, height: ITEM_WIDTH }]}
      onPress={() => router.push(`/profile/1?postId=${item.id}`)}
    >
      <Image
        source={{ uri: item.imageUrl }}
        style={styles.gridImage}
        resizeMode="cover"
      />
    </TouchableOpacity>
  );
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.username}>{user.username}</Text>
        <TouchableOpacity onPress={() => {}} style={styles.iconButton}>
          <Settings size={24} color={colors.textPrimary} />
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Info */}
        <View style={styles.profileInfo}>
          <View style={styles.profileHeader}>
            <Image
              source={{ uri: user.avatarUrl || undefined }}
              style={styles.profileImage}
            />
            
            <View style={styles.statsContainer}>
              <View style={styles.stat}>
                <Text style={styles.statNumber}>{user.postsCount}</Text>
                <Text style={styles.statLabel}>Posts</Text>
              </View>
              
              <TouchableOpacity style={styles.stat}>
                <Text style={styles.statNumber}>{user.followers}</Text>
                <Text style={styles.statLabel}>Followers</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.stat}>
                <Text style={styles.statNumber}>{user.following}</Text>
                <Text style={styles.statLabel}>Following</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <Text style={styles.fullName}>{user.fullName}</Text>
          {user.bio && <Text style={styles.bio}>{user.bio}</Text>}
          
          <View style={styles.actionsContainer}>
            <Button
              title="Edit Profile"
              variant="outline"
              style={styles.editButton}
              onPress={handleEditProfile}
            />
            
            <Button
              title="Log Out"
              variant="outline"
              style={styles.logoutButton}
              icon={<LogOut size={16} color={colors.primary} />}
              onPress={handleLogout}
            />
          </View>
        </View>
        
        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'posts' && styles.activeTab]}
            onPress={() => setActiveTab('posts')}
          >
            <Grid
              size={24}
              color={
                activeTab === 'posts' ? colors.primary : colors.textSecondary
              }
            />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'saved' && styles.activeTab]}
            onPress={() => setActiveTab('saved')}
          >
            <Bookmark
              size={24}
              color={
                activeTab === 'saved' ? colors.primary : colors.textSecondary
              }
            />
          </TouchableOpacity>
        </View>
        
        {/* Tab Content */}
        {activeTab === 'posts' ? (
          <FlatList
            data={MOCK_POSTS}
            renderItem={renderGridItem}
            keyExtractor={(item) => item.id}
            numColumns={NUM_COLUMNS}
            scrollEnabled={false}
            contentContainerStyle={styles.gridContainer}
          />
        ) : (
          <View style={styles.savedContainer}>
            <List size={64} color={colors.textSecondary} />
            <Text style={styles.savedText}>
              Items you save will appear here
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  username: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  iconButton: {
    padding: 4,
  },
  profileInfo: {
    padding: 16,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileImage: {
    width: 88,
    height: 88,
    borderRadius: 44,
    marginRight: 24,
  },
  statsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  fullName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  bio: {
    fontSize: 14,
    color: colors.textPrimary,
    marginTop: 4,
    lineHeight: 20,
  },
  actionsContainer: {
    flexDirection: 'row',
    marginTop: 16,
    gap: 8,
  },
  editButton: {
    flex: 1,
  },
  logoutButton: {
    flex: 0.4,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  gridContainer: {},
  gridItem: {
    padding: 1,
  },
  gridImage: {
    width: '100%',
    height: '100%',
  },
  savedContainer: {
    paddingVertical: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  savedText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
  },
  loadingText: {
    fontSize: 16,
    color: colors.textPrimary,
    textAlign: 'center',
    marginTop: 20,
  },
});