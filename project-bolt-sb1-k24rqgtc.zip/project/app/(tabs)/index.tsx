import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image, Platform } from 'react-native';
import { Camera, SquarePlus as PlusSquare } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { router } from 'expo-router';
import { colors } from '@/constants/theme';
import { StoriesRow, type StoryProps } from '@/components/stories/StoriesRow';
import { PostsList } from '@/components/post/PostsList';
import { PostProps } from '@/components/post/PostCard';

// Mock data for stories
const STORIES_DATA: StoryProps[] = [
  {
    id: '1',
    username: 'rishi',
    avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: true,
  },
  {
    id: '2',
    username: 'sarah_j',
    avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: true,
  },
  {
    id: '3',
    username: 'alex_m',
    avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: true,
    seen: true,
  },
  {
    id: '4',
    username: 'jason23',
    avatarUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: true,
  },
  {
    id: '5',
    username: 'emma_d',
    avatarUrl: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: true,
  },
  {
    id: '6',
    username: 'michael',
    avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    hasUnseenStory: false,
  },
];

// Mock data for posts
const POSTS_DATA: PostProps[] = [
  {
    id: '1',
    user: {
      id: '1',
      username: 'rishi',
      avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    imageUrl: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    caption: 'Exploring beautiful mountains this weekend! 🏔️ #adventure #nature #hiking',
    likesCount: 128,
    commentsCount: 24,
    timestamp: new Date(Date.now() - 3600000), // 1 hour ago
    location: 'Rocky Mountains, CO',
  },
  {
    id: '2',
    user: {
      id: '2',
      username: 'sarah_j',
      avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    imageUrl: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    caption: 'Sunday brunch vibes 🥐☕ #foodie #brunch #weekend',
    likesCount: 94,
    commentsCount: 8,
    timestamp: new Date(Date.now() - 7200000), // 2 hours ago
  },
  {
    id: '3',
    user: {
      id: '3',
      username: 'alex_m',
      avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    imageUrl: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    caption: 'Working from a different office today 💻 #wfh #productivity #coffeeaddict',
    likesCount: 56,
    commentsCount: 3,
    timestamp: new Date(Date.now() - 10800000), // 3 hours ago
    location: 'Urban Coffee Co.',
  },
];

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [refreshing, setRefreshing] = useState(false);
  
  const handleRefresh = () => {
    setRefreshing(true);
    // Simulate data fetching
    setTimeout(() => {
      setRefreshing(false);
    }, 1500);
  };
  
  const handleStoryPress = (id: string) => {
    router.push('/story');
  };
  
  const handleAddStoryPress = () => {
    // In a real app, this would open the camera to create a story
    alert('Add story functionality would open camera here');
  };
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <Image
          source={require('@/assets/images/logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
        
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconButton}>
            <PlusSquare size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.iconButton}
            onPress={() => router.push('/messages')}
          >
            <Camera size={24} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Stories and Posts */}
      <PostsList
        posts={POSTS_DATA}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        ListHeaderComponent={
          <StoriesRow
            stories={STORIES_DATA}
            onStoryPress={handleStoryPress}
            onAddStoryPress={handleAddStoryPress}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  logo: {
    height: 30,
    width: 120,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 16,
  },
});