import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList,
  TouchableOpacity,
  Image
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { formatDistanceToNow } from 'date-fns';
import { Avatar } from '@/components/ui/Avatar';
import { colors } from '@/constants/theme';
import { router } from 'expo-router';

// Notification types
type NotificationType = 'like' | 'comment' | 'follow' | 'mention' | 'tag';

interface Notification {
  id: string;
  type: NotificationType;
  user: {
    id: string;
    username: string;
    avatarUrl: string | null;
  };
  content?: string;
  postId?: string;
  postImage?: string;
  timestamp: Date;
  read: boolean;
}

// Mock notifications data
const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    type: 'like',
    user: {
      id: '2',
      username: 'sarah_j',
      avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    postId: '1',
    postImage: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=400',
    timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    read: false,
  },
  {
    id: '2',
    type: 'comment',
    user: {
      id: '3',
      username: 'alex_m',
      avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    content: 'Awesome photo! Where was this taken?',
    postId: '1',
    postImage: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=400',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    read: false,
  },
  {
    id: '3',
    type: 'follow',
    user: {
      id: '4',
      username: 'jason23',
      avatarUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    read: true,
  },
  {
    id: '4',
    type: 'mention',
    user: {
      id: '5',
      username: 'emma_d',
      avatarUrl: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    content: 'Hey @rishi check out this awesome place!',
    postId: '5',
    postImage: 'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg?auto=compress&cs=tinysrgb&w=400',
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    read: true,
  },
  {
    id: '5',
    type: 'like',
    user: {
      id: '6',
      username: 'michael',
      avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    postId: '3',
    postImage: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=400',
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    read: true,
  },
  {
    id: '6',
    type: 'tag',
    user: {
      id: '3',
      username: 'alex_m',
      avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    content: 'Tagged you in a post',
    postId: '6',
    postImage: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg?auto=compress&cs=tinysrgb&w=400',
    timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), // 4 days ago
    read: true,
  },
];

export default function NotificationsScreen() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [refreshing, setRefreshing] = useState(false);
  
  const handleRefresh = () => {
    setRefreshing(true);
    // Simulate data fetching
    setTimeout(() => {
      setRefreshing(false);
    }, 1500);
  };
  
  const getNotificationText = (notification: Notification): string => {
    switch (notification.type) {
      case 'like':
        return 'liked your post';
      case 'comment':
        return 'commented on your post';
      case 'follow':
        return 'started following you';
      case 'mention':
        return 'mentioned you in a comment';
      case 'tag':
        return 'tagged you in a post';
      default:
        return '';
    }
  };
  
  const handleNotificationPress = (notification: Notification) => {
    if (notification.postId) {
      if (notification.type === 'comment') {
        router.push(`/comments/${notification.postId}`);
      } else {
        router.push(`/profile/1?postId=${notification.postId}`);
      }
    } else if (notification.type === 'follow') {
      router.push(`/profile/${notification.user.id}`);
    }
    
    // Mark as read
    setNotifications(prev =>
      prev.map(n => (n.id === notification.id ? { ...n, read: true } : n))
    );
  };
  
  const renderNotification = ({ item }: { item: Notification }) => {
    const formattedTime = formatDistanceToNow(item.timestamp, { addSuffix: true });
    
    return (
      <TouchableOpacity
        style={[styles.notificationItem, !item.read && styles.unreadItem]}
        onPress={() => handleNotificationPress(item)}
      >
        <View style={styles.notificationContent}>
          <Avatar
            uri={item.user.avatarUrl}
            initials={item.user.username.substring(0, 2)}
            size="md"
          />
          <View style={styles.textContainer}>
            <Text style={styles.notificationText}>
              <Text style={styles.username}>{item.user.username}</Text>{' '}
              {getNotificationText(item)}
              {item.content && item.type === 'comment' && (
                <>
                  {': '}
                  <Text style={styles.comment} numberOfLines={1}>
                    {item.content}
                  </Text>
                </>
              )}
            </Text>
            <Text style={styles.timestamp}>{formattedTime}</Text>
          </View>
        </View>
        
        {item.postImage && (
          <Image
            source={{ uri: item.postImage }}
            style={styles.postThumbnail}
          />
        )}
      </TouchableOpacity>
    );
  };
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Activity</Text>
      </View>
      
      <FlatList
        data={notifications}
        renderItem={renderNotification}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        onRefresh={handleRefresh}
        refreshing={refreshing}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  list: {
    paddingVertical: 8,
  },
  notificationItem: {
    flexDirection: 'row',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  unreadItem: {
    backgroundColor: 'rgba(99, 102, 241, 0.08)', // Light primary color
  },
  notificationContent: {
    flexDirection: 'row',
    flex: 1,
    marginRight: 8,
  },
  textContainer: {
    marginLeft: 12,
    flex: 1,
  },
  notificationText: {
    fontSize: 14,
    color: colors.textPrimary,
    flexShrink: 1,
  },
  username: {
    fontWeight: '600',
  },
  comment: {
    fontStyle: 'italic',
  },
  timestamp: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  postThumbnail: {
    width: 44,
    height: 44,
    borderRadius: 4,
  },
});