import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  Image, 
  TouchableOpacity, 
  Dimensions,
  TextInput
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { X, Search } from 'lucide-react-native';
import { colors } from '@/constants/theme';

// Mock data for explore posts
interface ExploreItem {
  id: string;
  imageUrl: string;
  likesCount: number;
  commentsCount: number;
  userId: string;
}

const EXPLORE_DATA: ExploreItem[] = Array.from({ length: 20 }, (_, i) => {
  const id = (i + 1).toString();
  return {
    id,
    imageUrl: `https://images.pexels.com/photos/${1000000 + i * 53842}/pexels-photo-${1000000 + i * 53842}.jpeg?auto=compress&cs=tinysrgb&w=400`,
    likesCount: Math.floor(Math.random() * 1000),
    commentsCount: Math.floor(Math.random() * 100),
    userId: Math.floor(Math.random() * 10 + 1).toString(),
  };
});

const NUM_COLUMNS = 3;
const WINDOW_WIDTH = Dimensions.get('window').width;
const ITEM_WIDTH = WINDOW_WIDTH / NUM_COLUMNS;
const ITEM_HEIGHT = ITEM_WIDTH;

export default function ExploreScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  
  const renderItem = ({ item }: { item: ExploreItem }) => (
    <TouchableOpacity 
      style={styles.gridItem}
      onPress={() => router.push(`/profile/${item.userId}?postId=${item.id}`)}
    >
      <Image 
        source={{ uri: item.imageUrl }} 
        style={styles.itemImage}
        resizeMode="cover"
      />
    </TouchableOpacity>
  );
  
  const handleSearch = () => {
    // In a real app, this would trigger a search query
    console.log('Searching for:', searchQuery);
  };
  
  const clearSearch = () => {
    setSearchQuery('');
    setIsSearching(false);
  };
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="dark" />
      
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color={colors.textSecondary} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search"
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setIsSearching(true)}
            returnKeyType="search"
            onSubmitEditing={handleSearch}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={clearSearch}>
              <X size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
      </View>
      
      {isSearching && searchQuery.length > 0 ? (
        <View style={styles.searchResults}>
          <Text style={styles.searchResultsText}>
            No results found for "{searchQuery}"
          </Text>
        </View>
      ) : (
        <FlatList
          data={EXPLORE_DATA}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          numColumns={NUM_COLUMNS}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.gridContainer}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: colors.cardBackground,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.inputBackground,
    paddingHorizontal: 12,
    borderRadius: 8,
    height: 40,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: colors.textPrimary,
  },
  gridContainer: {
    paddingBottom: 20,
  },
  gridItem: {
    width: ITEM_WIDTH,
    height: ITEM_HEIGHT,
    padding: 1,
  },
  itemImage: {
    width: '100%',
    height: '100%',
  },
  searchResults: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  searchResultsText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});