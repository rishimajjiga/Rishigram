import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StoryViewer } from '@/components/stories/StoryViewer';

// Mock story data
const MOCK_STORIES = [
  {
    id: '1',
    imageUrl: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
  },
  {
    id: '2',
    imageUrl: 'https://images.pexels.com/photos/1174732/pexels-photo-1174732.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
  },
  {
    id: '3',
    imageUrl: 'https://images.pexels.com/photos/4046718/pexels-photo-4046718.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
  },
];

// Mock user data
const MOCK_USER = {
  id: '2',
  username: 'sarah_j',
  avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
};

export default function StoryScreen() {
  const handleClose = () => {
    router.back();
  };
  
  const handleReply = (storyId: string) => {
    // In a real app, this would open a reply input
    alert(`Replying to story ${storyId}`);
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <StoryViewer
        stories={MOCK_STORIES}
        user={MOCK_USER}
        onClose={handleClose}
        onReply={handleReply}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
});