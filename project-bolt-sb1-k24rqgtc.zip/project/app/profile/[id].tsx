import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  FlatList,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ArrowLeft, Grid2x2 as Grid, MoveHorizontal as MoreHorizontal } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import { Button } from '@/components/ui/Button';
import { PostCard, PostProps } from '@/components/post/PostCard';

// Mock user data
interface User {
  id: string;
  username: string;
  fullName: string;
  avatarUrl: string | null;
  bio: string | null;
  followers: number;
  following: number;
  isFollowing: boolean;
  postsCount: number;
}

const MOCK_USERS: Record<string, User> = {
  '1': {
    id: '1',
    username: 'rishi',
    fullName: 'Rishi Kumar',
    avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Photography enthusiast | Travel lover | Tech geek',
    followers: 1256,
    following: 426,
    isFollowing: false,
    postsCount: 42,
  },
  '2': {
    id: '2',
    username: 'sarah_j',
    fullName: 'Sarah Johnson',
    avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Adventure seeker | Food lover | Digital nomad',
    followers: 892,
    following: 305,
    isFollowing: true,
    postsCount: 27,
  },
  '3': {
    id: '3',
    username: 'alex_m',
    fullName: 'Alex Martinez',
    avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Designer | Coffee addict | Music lover',
    followers: 1547,
    following: 612,
    isFollowing: true,
    postsCount: 156,
  },
};

// Mock posts data
const MOCK_POSTS: Record<string, PostProps[]> = {
  '1': [
    {
      id: '1',
      user: {
        id: '1',
        username: 'rishi',
        avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      imageUrl: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      caption: 'Exploring beautiful mountains this weekend! 🏔️ #adventure #nature #hiking',
      likesCount: 128,
      commentsCount: 24,
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      location: 'Rocky Mountains, CO',
    },
    {
      id: '2',
      user: {
        id: '1',
        username: 'rishi',
        avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      imageUrl: 'https://images.pexels.com/photos/4046718/pexels-photo-4046718.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      caption: 'Coffee and productivity ☕ #workday #coffee #productive',
      likesCount: 94,
      commentsCount: 8,
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
    },
  ],
  '2': [
    {
      id: '3',
      user: {
        id: '2',
        username: 'sarah_j',
        avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      imageUrl: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      caption: 'Sunday brunch vibes 🥐☕ #foodie #brunch #weekend',
      likesCount: 94,
      commentsCount: 8,
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
    },
  ],
  '3': [
    {
      id: '4',
      user: {
        id: '3',
        username: 'alex_m',
        avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
      imageUrl: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      caption: 'Working from a different office today 💻 #wfh #productivity #coffeeaddict',
      likesCount: 56,
      commentsCount: 3,
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      location: 'Urban Coffee Co.',
    },
  ],
};

// Mock posts for grid view
const GRID_POSTS: Record<string, { id: string; imageUrl: string }[]> = {
  '1': Array.from({ length: 12 }, (_, i) => ({
    id: (i + 1).toString(),
    imageUrl: `https://images.pexels.com/photos/${900000 + i * 12345}/pexels-photo-${900000 + i * 12345}.jpeg?auto=compress&cs=tinysrgb&w=400`,
  })),
  '2': Array.from({ length: 8 }, (_, i) => ({
    id: (i + 1).toString(),
    imageUrl: `https://images.pexels.com/photos/${800000 + i * 12345}/pexels-photo-${800000 + i * 12345}.jpeg?auto=compress&cs=tinysrgb&w=400`,
  })),
  '3': Array.from({ length: 15 }, (_, i) => ({
    id: (i + 1).toString(),
    imageUrl: `https://images.pexels.com/photos/${700000 + i * 12345}/pexels-photo-${700000 + i * 12345}.jpeg?auto=compress&cs=tinysrgb&w=400`,
  })),
};

export default function ProfileScreen() {
  const { id, postId } = useLocalSearchParams<{ id: string; postId?: string }>();
  const insets = useSafeAreaInsets();
  const userId = id || '1'; // Default to first user if none specified
  
  const [user, setUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<PostProps[]>([]);
  const [gridPosts, setGridPosts] = useState<{ id: string; imageUrl: string }[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedPost, setSelectedPost] = useState<string | null>(postId || null);
  
  useEffect(() => {
    setUser(MOCK_USERS[userId]);
    setPosts(MOCK_POSTS[userId] || []);
    setGridPosts(GRID_POSTS[userId] || []);
  }, [userId]);
  
  const toggleFollow = () => {
    if (!user) return;
    
    setUser({
      ...user,
      isFollowing: !user.isFollowing,
      followers: user.isFollowing ? user.followers - 1 : user.followers + 1,
    });
  };
  
  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }
  
  // Render grid view
  const renderGridItem = ({ item, index }: { item: any; index: number }) => {
    const { width } = Dimensions.get('window');
    const size = width / 3;
    
    return (
      <TouchableOpacity
        style={[styles.gridItem, { width: size, height: size }]}
        onPress={() => setSelectedPost(item.id)}
      >
        <Image
          source={{ uri: item.imageUrl }}
          style={styles.gridImage}
          resizeMode="cover"
        />
      </TouchableOpacity>
    );
  };
  
  // If a post is selected, find it in our posts array
  const selectedPostData = selectedPost
    ? posts.find(post => post.id === selectedPost) ||
      (MOCK_POSTS['1'] && MOCK_POSTS['1'].find(post => post.id === selectedPost)) ||
      (MOCK_POSTS['2'] && MOCK_POSTS['2'].find(post => post.id === selectedPost)) ||
      (MOCK_POSTS['3'] && MOCK_POSTS['3'].find(post => post.id === selectedPost))
    : null;
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ArrowLeft size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{user.username}</Text>
        <TouchableOpacity>
          <MoreHorizontal size={24} color={colors.textPrimary} />
        </TouchableOpacity>
      </View>
      
      {selectedPostData ? (
        // Single post view
        <ScrollView>
          <TouchableOpacity
            style={styles.backToGrid}
            onPress={() => setSelectedPost(null)}
          >
            <Grid size={20} color={colors.primary} />
            <Text style={styles.backToGridText}>Back to Grid</Text>
          </TouchableOpacity>
          <PostCard {...selectedPostData} />
        </ScrollView>
      ) : (
        // Profile view
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Profile Info */}
          <View style={styles.profileInfo}>
            <View style={styles.profileHeader}>
              <Image
                source={{ uri: user.avatarUrl || undefined }}
                style={styles.profileImage}
              />
              
              <View style={styles.statsContainer}>
                <View style={styles.stat}>
                  <Text style={styles.statNumber}>{user.postsCount}</Text>
                  <Text style={styles.statLabel}>Posts</Text>
                </View>
                
                <TouchableOpacity style={styles.stat}>
                  <Text style={styles.statNumber}>{user.followers}</Text>
                  <Text style={styles.statLabel}>Followers</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.stat}>
                  <Text style={styles.statNumber}>{user.following}</Text>
                  <Text style={styles.statLabel}>Following</Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <Text style={styles.fullName}>{user.fullName}</Text>
            {user.bio && <Text style={styles.bio}>{user.bio}</Text>}
            
            <View style={styles.actionsContainer}>
              <Button
                title={user.isFollowing ? 'Following' : 'Follow'}
                variant={user.isFollowing ? 'outline' : 'primary'}
                style={styles.actionButton}
                onPress={toggleFollow}
              />
              
              <Button
                title="Message"
                variant="outline"
                style={styles.actionButton}
                onPress={() => router.push(`/chat/${user.id}`)}
              />
            </View>
          </View>
          
          {/* Posts Grid */}
          <View style={styles.postsContainer}>
            <FlatList
              data={gridPosts}
              renderItem={renderGridItem}
              keyExtractor={(item) => item.id}
              numColumns={3}
              scrollEnabled={false}
            />
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  profileInfo: {
    padding: 16,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileImage: {
    width: 88,
    height: 88,
    borderRadius: 44,
    marginRight: 24,
  },
  statsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  fullName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  bio: {
    fontSize: 14,
    color: colors.textPrimary,
    marginTop: 4,
    lineHeight: 20,
  },
  actionsContainer: {
    flexDirection: 'row',
    marginTop: 16,
    gap: 8,
  },
  actionButton: {
    flex: 1,
  },
  postsContainer: {
    marginTop: 8,
  },
  gridItem: {
    padding: 1,
  },
  gridImage: {
    width: '100%',
    height: '100%',
  },
  loadingText: {
    fontSize: 16,
    color: colors.textPrimary,
    textAlign: 'center',
    marginTop: 20,
  },
  backToGrid: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 16,
    backgroundColor: colors.cardBackground,
  },
  backToGridText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.primary,
  },
});