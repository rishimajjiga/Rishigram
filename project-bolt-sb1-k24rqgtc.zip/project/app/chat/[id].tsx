import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ArrowLeft, Video, Phone, MoveVertical as MoreVertical } from 'lucide-react-native';
import { Avatar } from '@/components/ui/Avatar';
import { ChatBubble, MessageType } from '@/components/chat/ChatBubble';
import { ChatInput } from '@/components/chat/ChatInput';
import { colors } from '@/constants/theme';

// Mock data for the current user
const CURRENT_USER_ID = '1';

// Mock data types
interface Message {
  id: string;
  text: string;
  senderId: string;
  timestamp: Date;
  type: MessageType;
  status: 'sent' | 'delivered' | 'read';
}

interface ChatUser {
  id: string;
  username: string;
  avatarUrl: string | null;
  isOnline: boolean;
  lastActive?: Date;
}

// Mock data for the chat
const MOCK_USERS: Record<string, ChatUser> = {
  '1': {
    id: '1',
    username: 'rishi',
    avatarUrl: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isOnline: true,
  },
  '2': {
    id: '2',
    username: 'sarah_j',
    avatarUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isOnline: true,
  },
  '3': {
    id: '3',
    username: 'alex_m',
    avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isOnline: false,
    lastActive: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
  },
};

const MOCK_MESSAGES: Record<string, Message[]> = {
  '1': [
    {
      id: '1',
      text: 'Hey, how are you?',
      senderId: '2',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '2',
      text: 'I\'m good, thanks! How about you?',
      senderId: '1',
      timestamp: new Date(Date.now() - 1.9 * 60 * 60 * 1000), // 1.9 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '3',
      text: 'Doing great! Check out this photo from my hike yesterday',
      senderId: '2',
      timestamp: new Date(Date.now() - 1.8 * 60 * 60 * 1000), // 1.8 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '4',
      text: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      senderId: '2',
      timestamp: new Date(Date.now() - 1.7 * 60 * 60 * 1000), // 1.7 hours ago
      type: 'image',
      status: 'read',
    },
    {
      id: '5',
      text: 'Wow, that\'s beautiful! Where is that?',
      senderId: '1',
      timestamp: new Date(Date.now() - 1.5 * 60 * 60 * 1000), // 1.5 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '6',
      text: 'Rocky Mountain National Park. We should go sometime!',
      senderId: '2',
      timestamp: new Date(Date.now() - 1.4 * 60 * 60 * 1000), // 1.4 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '7',
      text: 'Definitely! I\'d love to go hiking there.',
      senderId: '1',
      timestamp: new Date(Date.now() - 1.2 * 60 * 60 * 1000), // 1.2 hours ago
      type: 'text',
      status: 'read',
    },
    {
      id: '8',
      text: '🏔️❤️',
      senderId: '2',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      type: 'emoji',
      status: 'read',
    },
    {
      id: '9',
      text: 'Are you coming to the event tonight?',
      senderId: '2',
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      type: 'text',
      status: 'read',
    },
  ],
  '2': [
    {
      id: '1',
      text: 'Hi there!',
      senderId: '3',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      type: 'text',
      status: 'read',
    },
    {
      id: '2',
      text: 'Hey! What\'s up?',
      senderId: '1',
      timestamp: new Date(Date.now() - 0.9 * 60 * 60 * 1000), // 54 minutes ago
      type: 'text',
      status: 'read',
    },
    {
      id: '3',
      text: 'Not much, just working on that project we discussed',
      senderId: '3',
      timestamp: new Date(Date.now() - 0.8 * 60 * 60 * 1000), // 48 minutes ago
      type: 'text',
      status: 'read',
    },
    {
      id: '4',
      text: 'I\'ll send you some info about it',
      senderId: '3',
      timestamp: new Date(Date.now() - 0.7 * 60 * 60 * 1000), // 42 minutes ago
      type: 'text',
      status: 'read',
    },
    {
      id: '5',
      text: 'Sounds good!',
      senderId: '1',
      timestamp: new Date(Date.now() - 0.6 * 60 * 60 * 1000), // 36 minutes ago
      type: 'text',
      status: 'read',
    },
    {
      id: '6',
      text: 'Thanks for the info!',
      senderId: '1',
      timestamp: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago
      type: 'text',
      status: 'delivered',
    },
  ],
};

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const listRef = useRef<FlatList>(null);
  
  const chatId = id || '1'; // Default to first chat if none specified
  const otherUserId = chatId === '1' ? '2' : '3';
  const chatUser = MOCK_USERS[otherUserId];
  
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES[chatId] || []);
  
  useEffect(() => {
    // Scroll to bottom when component mounts
    setTimeout(() => {
      listRef.current?.scrollToEnd({ animated: false });
    }, 200);
  }, []);
  
  const sendMessage = (text: string, type: MessageType = 'text') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      senderId: CURRENT_USER_ID,
      timestamp: new Date(),
      type,
      status: 'sent',
    };
    
    setMessages(prev => [...prev, newMessage]);
    
    // Scroll to bottom
    setTimeout(() => {
      listRef.current?.scrollToEnd({ animated: true });
    }, 100);
    
    // Simulate message status update
    setTimeout(() => {
      setMessages(prev =>
        prev.map(msg =>
          msg.id === newMessage.id ? { ...msg, status: 'delivered' } : msg
        )
      );
    }, 1000);
    
    // Simulate auto-reply for demo
    if (type === 'text' && Math.random() > 0.5) {
      setTimeout(() => {
        const autoReply: Message = {
          id: (Date.now() + 1).toString(),
          text: 'Auto reply: Got your message!',
          senderId: otherUserId,
          timestamp: new Date(),
          type: 'text',
          status: 'sent',
        };
        
        setMessages(prev => [...prev, autoReply]);
        
        setTimeout(() => {
          listRef.current?.scrollToEnd({ animated: true });
        }, 100);
      }, 2000);
    }
  };
  
  const startRecording = () => {
    // In a real app, this would start voice recording
    console.log('Start recording');
  };
  
  const stopRecording = () => {
    // In a real app, this would stop recording and send voice message
    console.log('Stop recording');
    
    // For demo, let's simulate sending a text message
    sendMessage('🎤 [Voice message]');
  };
  
  if (!chatUser) {
    return (
      <View style={styles.container}>
        <Text>Chat not found</Text>
      </View>
    );
  }
  
  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ArrowLeft size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.userInfo} onPress={() => {}}>
          <Avatar
            uri={chatUser.avatarUrl}
            initials={chatUser.username.substring(0, 2)}
            size="sm"
            showOnlineIndicator
            isOnline={chatUser.isOnline}
          />
          <View>
            <Text style={styles.username}>{chatUser.username}</Text>
            <Text style={styles.onlineStatus}>
              {chatUser.isOnline ? 'Online' : 'Offline'}
            </Text>
          </View>
        </TouchableOpacity>
        
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionButton}>
            <Video size={20} color={colors.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Phone size={20} color={colors.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <MoreVertical size={20} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Chat Messages */}
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ChatBubble
            message={item.text}
            timestamp={item.timestamp}
            isCurrentUser={item.senderId === CURRENT_USER_ID}
            type={item.type}
            status={item.status}
          />
        )}
        contentContainerStyle={styles.messagesContainer}
      />
      
      {/* Chat Input */}
      <ChatInput
        onSendMessage={sendMessage}
        onStartRecording={startRecording}
        onStopRecording={stopRecording}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.cardBackground,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginLeft: 16,
    gap: 8,
  },
  username: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  onlineStatus: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  messagesContainer: {
    paddingVertical: 16,
  },
});